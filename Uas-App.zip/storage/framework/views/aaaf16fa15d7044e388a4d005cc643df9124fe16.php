
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <?php if(session('message')): ?>
            <script>
                Swal.fire(
                    'Good job!',
                    '<?php echo e(session("message")); ?>',
                    'success'
                )
            </script>
            <?php endif; ?>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="zero_config" class="table table-striped table-bordered no-wrap">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Transaski</th>
                                <th>Tanggal Transaksi</th>
                                <th>Harga</th>
                                <th>QTY</th>
                                <th>Barang</th>
                                <th>Discount</th>
                                <th>Nama Pelanggan</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($row->nama_transaksi); ?></td>
                                <td><?php echo e($row->tgl_transaksi); ?></td>
                                <td> Rp,<?php echo e(number_format($row->harga)); ?></td>
                                <td><?php echo e($row->qty); ?></td>
                                <td><?php echo e($row->nama_barang); ?></td>
                                <td><?php echo e($row->diskon); ?>%</td>
                                <td><?php echo e($row->nama_pelanggan); ?></td>
                                <td>
                                    <a href="<?php echo e(url('admin/generatereport')); ?>/<?php echo e($row->id_transaksi); ?>" class="btn btn-warning fa fa-print"></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <ul class="pagination float-right">
                        <li class="page-item disabled">
                            <a class="page-link" href="#" tabindex="-1">Previous</a>
                        </li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#">Next</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Uas-App\resources\views/pages/transaksi/index.blade.php ENDPATH**/ ?>