
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h3 class="mb-4">Buat Transaksi Barumu!</h3>
                <form method="POST" action="<?php echo e(url('admin/store/transaksi')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Nama Transaksi</label>
                                    <input name="transaksi" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Transaksi">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Tanggal Transaksi</label>
                                    <input name="tanggal_transaksi" type="date" class="form-control" id="exampleInputPassword1" placeholder="Eneter Tanggal">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Qty</label>
                                    <input name="qty" type="number" class="form-control" id="exampleInputPassword1" placeholder="Eneter Qty">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Disc</label>
                                    <input name="disc" type="number" class="form-control" id="exampleInputPassword1" placeholder="Eneter Disount">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Barang</label>
                                    <select name="barang" class="form-control">
                                        <option>--- PILIH ---</option>
                                        <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->id_barang); ?>"><?php echo e($row->nama_barang); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Pelanggan</label>
                                    <select name="pelanggan" class="form-control">
                                        <option>--- PILIH ---</option>
                                        <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->id_pelanggan); ?>"><?php echo e($row->nama_pelanggan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary float-right">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Uas-App\resources\views/pages/transaksi/transaksi.blade.php ENDPATH**/ ?>